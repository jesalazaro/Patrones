//package CriticalSection;

public class ClientManager {

	public static void main(String[] args) {

		FileProcess proceso1 = new FileProcess("Thread 1 is wrtting");
		proceso1.start();
		FileProcess proceso2 = new FileProcess("Thread 2 is writting");
		proceso2.start();
		FileProcess proceso3 = new FileProcess("Thread 3 is wrtting");
		proceso3.start();
		FileProcess proceso4 = new FileProcess("Thread 4 is writting");
		proceso4.start();
	}
}

class FileProcess extends Thread {
	private String msgLog;

	public FileProcess(String msg) {
		this.msgLog = msg;
	}

	@Override
	public void run() {
		long t1 = 0, t2 = 0, t1_r = 0, t2_r = 0;


		t1 = System.nanoTime();
		Logger fileLogger = FileLogger.getFileLogger();
		t2 = System.nanoTime();

		System.out.println((t2 - t1));

		t1_r = System.nanoTime();

		for (int i = 0; i < 100; i++) {
			fileLogger.log(msgLog);
		}

		t2_r = System.nanoTime();

		System.out.println((t2_r - t1_r));

	}
}
