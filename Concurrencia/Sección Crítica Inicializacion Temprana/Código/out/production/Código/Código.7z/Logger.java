public interface Logger {
  public void log(String msg);
}
